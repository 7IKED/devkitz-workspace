# ?? DEVKiTZ REGELWERK  kosystem-Regeln

> [!CAUTION]
> **PARSER-SCHLEIFENSCHUTZ (LOOP PREVENTION):**
> Um Endlosschleifen und Truncation-Fehler zu vermeiden, dürfen diese Referenz-Dokumente (`CLAUDE.md`, `GEMINI.md`, `REGELWERK.md`, `DKZ_PLAYBOOK.md`) **NICHT** nacheinander, präventiv oder rekursiv eingelesen werden. Lies sie nur, wenn sie für die konkrete Aufgabe direkt benötigt werden.

> **Version:** v1.06.0_01 | **Stand:** 2026-03-11 | **Regeln:** 25 (0-24) | **Status:** AKTIV
> **Zweck:** JEDES LLM / jeder Agent / jeder Entwickler MUSS dieses Dokument vor Arbeitsbeginn lesen (Schleifenschutz beachten!).
> **Pfad:** `C:\DEVKiTZ\REGELWERK.md`

---

## ?? PFLICHT-LESELISTE VOR ARBEITSBEGINN

Vor jeder Arbeit am DEVKiTZ �kosystem M�SSEN folgende Dateien gelesen werden:

1. **`REGELWERK.md`** ? DU BIST HIER � Alle Regeln
2. **`04_SYSTEM/claude.md`** � Projekt-Identit�t, Architektur, Arbeitsweise
3. **`01_PROJECTS/01_dashboard/REGISTRY.json`** � Master-Index aller Module
4. **`01_PROJECTS/01_dashboard/BLAUPAUSE.md`** � Architektur-Blueprint
5. **`.agents/workflows/`** � Workflow-Regeln

## ??? OBERSTE REGEL � �BER ALLEM

### Regel 0: SEI IMMER EIN TEIL DER L�SUNG, NIE DES PROBLEMS
> **Dies ist die Grundlage von ALLEM.**
> Jede Handlung, jede Entscheidung, jeder Commit, jede Zeile Code
> muss das System **besser** machen, nicht komplizierter.
>
> - Probleme werden gel�st, nicht weitergereicht
> - Fehler werden behoben, nicht versteckt
> - Hindernisse werden beseitigt, nicht umgangen
> - L�sungen werden dokumentiert, nicht nur implementiert
>
> **Wenn du vor einer Entscheidung stehst, frag dich:**
> *�Bin ich gerade Teil der L�sung oder Teil des Problems?"*

---

## ?? KRITISCHE REGELN (KEINE AUSNAHMEN)

### Regel 1: NIE L�SCHEN � IMMER ARCHIVIEREN
> **Das h�chste Gut das wir haben ist unser Wissen und der Log unserer Arbeit.**
> Nur damit k�nnen wir analysieren was man besser machen kann und wo Probleme herkommen.
>
> Dateien, Wissen, Informationen und Daten werden **NIEMALS** gel�scht.
> Stattdessen werden sie nach `99_ARCHIVE/` oder `99_archived/` verschoben.
> **Keine Ausnahme. Kein Argument. Niemals.**
>
> **Warum das so wichtig ist:**
> - Gel�schtes Wissen ist f�r immer verloren � kein Undo
> - Alte Fehler lehren neue L�sungen � wenn man sie nachschauen kann
> - Arbeitsprotokolle zeigen Muster � wo hakt es, wo l�uft es gut
> - Archiviertes Material kann morgen Gold wert sein

### Regel 2: GIT COMMIT NACH JEDER �NDERUNG
> Jede Datei�nderung bekommt **sofort** einen Git-Commit.
> Format: `prefix(bereich): was wurde gemacht`
> Prefixe: `feat`, `fix`, `chore`, `docs`, `style`, `refactor`, `init`
> Details: `.agents/workflows/git-after-every-step.md`

### Regel 3: ALLES MUSS VORHANDEN BLEIBEN
> Nichts darf sich �in Luft aufl�sen". Dateien und Wissen m�ssen **immer** nachverfolgbar sein.
> Bei Umstrukturierung: **Kopieren** statt Verschieben wenn unsicher. Original bleibt bis Kopie verifiziert.

### Regel 4: SEI PROAKTIV BEI VERBESSERUNGEN UND OPTIMIERUNGEN
> **Aktive Verbesserung ist Pflicht**, solange sie n�tig ist oder einen erheblichen Mehrwert verspricht.
> - Wenn du eine offensichtliche Verbesserung siehst: **vorschlagen und umsetzen**
> - Wenn eine Optimierung das System stabiler, schneller oder wartbarer macht: **machen**
> - Wenn ein Workflow ineffizient ist: **verbessern, nicht ignorieren**
> - Wenn Dokumentation unvollst�ndig ist: **erg�nzen**
>
> **Grenze:** Proaktivit�t gilt nur unter **ausnahmsloser Einhaltung aller anderen Regeln**.
> Insbesondere: Regel 1 (nie l�schen), Regel 3 (alles bleibt), Regel 11 (Dateihoheit),
> Regel 15 (so wenig wie m�glich), Regel 16 (Regeln �ber Anweisungen).
> Keine Verbesserung rechtfertigt einen Regelbruch.
>
> *Hinweis: Der alte Markenname �ANTICRAV" wurde vollst�ndig durch DEVKiTZ ersetzt und darf nirgends mehr verwendet werden.*

---

## ?? ARBEITSREGELN

### Regel 5: ERST ANALYSIEREN, DANN HANDELN
> Vor jeder �nderung: Detailliert analysieren wie etwas am besten passt.
> Keine blindes Verschieben, kein Trial-and-Error mit Produktivdaten.

### Regel 6: KOMPATIBILIT�TSPR�FUNG VOR INTEGRATION
> Bevor etwas ins System eingebunden wird:
> 1. Pr�fen ob es fehlerfrei ins �kosystem passt
> 2. Testen ob es bestehende Funktionalit�t bricht
> 3. Bei Konflikten: **WARNEN** und User fragen

### Regel 7: WAS NICHT REINPASST ? INWORK SPACE
> Nicht-kompatible Inhalte parallel aufbewahren in `00_INBOX/RAW/`
> Niemals l�schen, nur verschieben und kategorisieren.

### Regel 8: PRIVATE DATEIEN ? 05_INTERN/privat/
> Lebenslauf, pers�nliche Dokumente, private Verkn�pfungen separat halten.
> Nicht in �ffentliche oder Projekt-Ordner mischen.

### Regel 9: DkZ VERSIONIERUNG � v1.01.1_01 FORMAT
> **Format:** `vX.XX.X_XX` ? `v[Hauptversion].[Feature].[Session]_[Step]`
>
> | Stelle | Bedeutung | Wann �ndern? |
> |:---|:---|:---|
> | `v1` | Hauptversion | Nur bei komplettem Rebuild / Systemwechsel |
> | `.01` | Feature-Version | Neue Features, Umstrukturierungen |
> | `.1` | Session-Nummer | Neue Session die das Tool/Projekt betrifft |
> | `_01` | Step innerhalb der Session | Jeder einzelne Schritt in der Session |
>
> **Ablauf-Logik:**
> ```
> v1.01.1_01 ? v1.01.1_02 ? v1.01.1_03   ? Steps in Session 1
>                                 ? Session endet
> v1.01.2_01 ? v1.01.2_02 ? ...           ? Neue Session
>                                 ? Neues Feature
> v1.02.1_01 ? ...                         ? Feature-Version steigt
> ```
>
> **Lifecycle-Stufen:**
> - `v0.XX` = **Alpha** (unver�ffentlicht, intern)
> - `v01.XX` = **Beta** (erste �ffentliche Tests)
> - `v1.XX` = **Release** (Master/Production)
>
> **Kernregel:**
> - Build l�uft ? nur `_XX` erh�hen
> - Session abgeschlossen ? `.X` erh�hen
> - Umbau / neues Feature ? `.XX` (mittlere Stelle) erh�hen
> - Komplett neues System ? `vX` erh�hen

### Regel 15: �NDERE SO VIEL WIE N�TIG, ABER SO WENIG WIE M�GLICH
> **Minimale Intervention.** Nur exakt das �ndern, was angefordert wurde.
> - Keine �Bonus-Refactorings" ohne Auftrag
> - Keine Seiteneffekte auf andere Module/Dateien
> - Code-�nderungen chirurgisch pr�zise, nicht fl�chendeckend
> - Wenn mehr n�tig ist: **zuerst fragen**, dann �ndern

### Regel 16: REGELN STEHEN �BER ANWEISUNGEN
> **Die Regeln in diesem Dokument sind bindend � immer.**
> Wenn eine Anweisung gegen eine Regel verst��t:
> 1. Die Regel hat Vorrang
> 2. Den Konflikt dem User melden
> 3. Nachfragen ob die Regel f�r diesen Fall ausgesetzt werden soll
> 4. NUR bei **ausdr�cklicher Best�tigung** die Regel �bergehen
>
> **Kein LLM / Agent darf eigenst�ndig Regeln brechen.**
> Das gilt besonders f�r Regel 1 (Nie l�schen), Regel 3 (Alles bleibt vorhanden)
> und Regel 11 (Dateihoheit).

### Regel 17: IMMER ZUERST ORDNER.ini LESEN
> **Bevor in einem Ordner gearbeitet wird: `ORDNER.ini` lesen.**
> Jeder Hauptordner hat eine `ORDNER.ini` mit:
> - Ordner-Typ und Beschreibung
> - Geltende Regeln f�r diesen Ordner
> - Verweise auf wichtige Dateien
> - Workflow-Anweisungen
>
> **Wenn etwas im Ordner ge�ndert wird ? ORDNER.ini aktualisieren.**
> So findet jedes LLM ohne Ged�chtnis sofort alle Regeln.

### Regel 18: AUTO-DOKUMENTATION & PROMPT-ARCHIV
> **Bei jeder erstmaligen Aktion oder undokumentierten Aufgabe:**
> 1. **Dokumentation erstellen** � Was wurde gemacht, wie, warum
> 2. **Action-Eintrag** � In das Workflow/Action-Log eintragen
> 3. **Prompt-Archiv f�ttern** � Erfolgreiche Prompts/Anweisungen speichern
>
> **Was wird archiviert:**
>
> | Typ | Was | Wo |
> |:---|:---|:---|
> | Actions | Workflows, Skills, Trigger, Quellen | `04_SYSTEM/SYSTEM/_agents/` |
> | Prompts | Erfolgreiche Prompts + Bewertung | `04_SYSTEM/SYSTEM/_agents/snippets/` |
> | Verweise | Cross-Links, Referenzen, Cons | `04_SYSTEM/SYSTEM/_agents/references/` |
> | Agenten | Agent-Konfigurationen, Personas | `04_SYSTEM/SYSTEM/_agents/agent-prompts/` |
>
> **Warum das so wichtig ist:**
> - LLMs brauchen Anweisungen dar�ber, wie gut Prompts funktioniert haben
> - Fehlersuche wird einfacher wenn man sieht was vorher lief
> - Prompt-Archiv w�chst automatisch ? bessere Ergebnisse �ber Zeit
> - Jedes LLM kann aus dem Archiv lernen, auch ohne Ged�chtnis
>
> **Bewertungsformat f�r Prompts:**
> `[QUALITY: 1-5] [RESULT: success/partial/fail] [REUSABLE: yes/no]`

### Regel 19: ABSCHLUSS-ANALYSE NACH JEDEM PROJEKT / VOLLER AUFGABE
> **Am Ende jedes Projekts oder abgeschlossenen Aufgabenblockes:**
> 1. **Vollst�ndigkeits-Check** � Alle Anfragen bearbeitet?
> 2. **Dokumentations-Check** � BLAUPAUSE, REGISTRY, ORDNER.ini aktuell?
> 3. **Git-Check** � Alles committed? Uncommitted changes?
> 4. **Konsistenz-Check** � Modulzahlen stimmen �berein?
> 5. **L�cken-Fix** � Gefundene L�cken sofort schlie�en
>
> **Erst wenn alles gr�n ist ? Aufgabe ist abgeschlossen.**
> Diese Analyse ist Pflicht, nicht optional.

### Regel 20: DOKUMENTATIONS-PFLICHT & VERSIONIERUNG
> **Nach JEDER funktionalen �nderung, Ablauf�nderung oder Verfahrens�nderung
> MUSS die betroffene Dokumentation sofort aktualisiert werden.**
>
> - Dokumentation wird via Git versioniert (`doc-sync.js`)
> - �nderungen die nicht besser waren ? Git Rollback
> - Jede Dok-�nderung wird im Event-Log protokolliert (`DkzEventLog.logDocChange()`)
> - 5 separate Git-Archive werden gepflegt:
>   - `prompts/` � Prompt-Archiv
>   - `snippets/` � Code-Snippets
>   - `workflows/` � Workflow-Definitionen
>   - `agents/` � Agenten-Konfigurationen
>   - `blueprints/` � Blaupausen & Implementierungspl�ne
>
> **Regel: Kein Code ohne Dokumentation. Keine �nderung ohne Update.**

### Regel 21: SHARED SCRIPTS PFLICHT
> **Jedes Dashboard-Modul MUSS die Shared Scripts einbinden:**
> - `dkz-debug.js` � XSS-Schutz (`esc()`), Fehler-Overlay (**PFLICHT**)
> - `dkz-copilot.js` � LLM Chat mit Google Technik 6-Part
> - `dkz-llm-registry.js` � 8 Provider, 60+ Modelle, Cost-Tracking
> - `dkz-eventlog.js` � Event-Bus und Event-Tracking
>
> **Einbindung:** `<script src="../../shared/dkz-debug.js"></script>` in jedem Modul.
> Ohne `dkz-debug.js` ist ein Modul **nicht deploybar**.

### Regel 22: FEATURES.JSON PFLICHT
> **Jedes Modul/Dashboard MUSS eine `features.json` haben.**
> Pflichtfelder: `id`, `name`, `version`, `description`, `features[]`.
> Jedes Feature hat `name` + `status` (done/wip/planned).
> Nach Erstellung: REGISTRY.json aktualisieren + BLAUPAUSE.md erg�nzen.

### Regel 23: R23 � GO?PYTHON FALLBACK (IMMER ANWENDEN)
> **Jede `.go` Datei MUSS eine `.py` Fallback-Datei haben.**
>
> | Status | Runtime | Farbe |
> |:---|:---|:---|
> | ?? GR�N | Go (schnell, nativ) | Primary |
> | ?? GELB | Python (funktional) | Fallback |
> | ?? ROT | Offline | Error |
>
> **Regeln:**
> - `start.bat` / `start.sh` erkennt automatisch ob Go oder Python verf�gbar
> - Go = bevorzugt, Python = automatischer Fallback
> - Python-Server spiegelt alle Go-Endpoints 1:1 (identische API)
> - Dashboard zeigt Runtime-Farbe (??/?? � **nicht rot f�r Python!**)
> - Copilot-Aufgabe: Wenn `.go` ohne `.py` gefunden ? Issue + Auto-Erstellung
> - Drive-Backup vor jedem Runtime-Wechsel (Katalog + James + Scores + Meta)
>
> **Aktuell betroffen:** Iceberg Knowledge Lake (Port 9881)
> - Go: `BACKEND/iceberg/main.go`
> - Python: `BACKEND/iceberg/server.py`
> - Starter: `BACKEND/iceberg/start.bat` / `start.sh`

---

## ?? FLUSS- & SOUVER�NIT�TS-REGELN

### Regel 10: DER OPTIMALE WORKFLOW IST WICHTIGER ALS DAS ERGEBNIS
> **Kernphilosophie des gesamten �kosystems.**
> Wenn der Workflow stimmt, kann man am Ergebnis arbeiten bis es besser wird.
> Ein schlechtes Ergebnis mit gutem Workflow ist reparierbar.
> Ein gutes Ergebnis mit schlechtem Workflow ist Zufall und nicht reproduzierbar.
>
> **Konkret bedeutet das:**
> 1. Immer den sauber dokumentierten Weg zum Ziel w�hlen
> 2. Lieber langsamer und strukturiert als schnell und chaotisch
> 3. Jeden Schritt nachvollziehbar machen (Git, Logs, Dokumentation)
> 4. Prozesse optimieren hat Vorrang vor Feature-Jagd

### Regel 11: DATEIHOHEIT � ABSOLUTE KONTROLLE �BER ALLE DATEN
> Der Benutzer hat **jederzeit volle Kontrolle** �ber alle Dateien im System.
> Kein automatischer Prozess darf Dateien ohne Best�tigung:
> - �berschreiben (immer Backup vorher)
> - Entfernen (nur archivieren, nie l�schen � siehe Regel 1)
> - Zusammenf�hren (Konflikte explizit melden)
> - An externe Dienste senden
>
> **Bei jeder Datei-Operation gilt:**
> - Quelle und Ziel klar benennen
> - Vorher/Nachher nachvollziehbar machen
> - Bei Massenoperationen: Liste anzeigen, Best�tigung einholen

### Regel 12: KEIN VERLUST VON WISSEN ODER ARBEITSVORG�NGEN
> **Wissen** (Dokumente, Notizen, Analysen, Konzepte) und
> **Arbeitsvorg�nge** (Commits, Logs, Entscheidungen, Fehlerberichte)
> werden **NIEMALS** verworfen.
>
> **Sicherungsschichten:**
> 1. **Git History** � Jeder Commit ist ein Checkpoint
> 2. **99_ARCHIVE/** � Archivierte Dateien bleiben auf Platte
> 3. **02_RESEARCH/** � Wissen wird katalogisiert, nicht gel�scht
> 4. **00_INBOX/RAW/** � Rohdaten bleiben sortiert verf�gbar
> 5. **[DEEPKEEP]/** � KI-Chats und Exporte dauerhaft gesichert
>
> **Wenn etwas �nicht mehr gebraucht wird":**
> ? Archivieren, taggen, katalogisieren. NICHT l�schen.

### Regel 13: WORKFLOW-FLUSS SICHERSTELLEN
> Jede Arbeitssequenz folgt einem klaren Fluss:
>
> ```
> ANALYSE ? PLAN ? GENEHMIGUNG ? AUSF�HRUNG ? VERIFIKATION ? COMMIT ? DOKUMENTATION
>    ?                                                                       �
>    +--------------------- Feedback-Loop ----------------------------------+
> ```
>
> **Fluss-Regeln:**
> - Kein Schritt wird �bersprungen
> - Bei Unsicherheit: zur�ck zu ANALYSE
> - Bei Fehler: VERIFIKATION wiederholen, nicht ignorieren
> - Jeder Schritt hat ein Ergebnis (Commit, Dokument, oder Entscheidung)
> - Blockaden sofort melden, nicht still umgehen

### Regel 14: KONTINUIERLICHE VERBESSERUNG � KAIZEN
> Das System wird **jeden Tag besser**, nie schlechter.
> - Jede Arbeitssession hinterl�sst das System in besserem Zustand
> - Fehler werden sofort gefixt, nicht �f�r sp�ter" notiert
> - Neue Erkenntnisse ? REGELWERK aktualisieren
> - Neue Regeln ? sofort hier eintragen + Git commit
> - Workflows die nicht funktionieren ? anpassen, nicht ignorieren

---

## ?? ORDNERSTRUKTUR

```
C:\DEVKiTZ\
+-- 00_INBOX/          ? Eingang, Downloads, unsortiert, RAW-Dateien
�   +-- RAW/           ? Rohdaten kategorisiert (projekte/scripts/code/dokumente)
�   +-- downloads/     ? Browser-Downloads
�   +-- unsorted/      ? Noch nicht einsortiert
+-- 01_PROJECTS/       ? Alle aktiven Projekte (01-11 + 99_archived)
�   +-- 01_dashboard/  ? DkZ Dashboard (59 Module, 14 Dashboards)
+-- 02_RESEARCH/       ? Forschung, Dokumentation, Podcasts
+-- 03_MEDIA/          ? Bilder, Videos, AI-generiert
+-- 04_SYSTEM/         ? System-Dateien, Configs, KI-Memory
+-- 05_INTERN/         ? Private und allgemeine Dokumente
�   +-- privat/        ? Pers�nliche Dokumente
�   +-- allgemein/     ? Allgemeine Informationen
+-- 99_ARCHIVE/        ? Archivierte Inhalte (web-snapshots, etc.)
+-- [DEEPKEEP]/        ? AI-Chat Archiv (8 Plattformen)
+-- .agents/           ? Workflows und Automatisierung
+-- REGELWERK.md       ? DU BIST HIER
+-- .gitignore
```

---

## ?? MODUL-KONVENTIONEN

### Neue Module erstellen
1. Ordner: `modules/kebab-case/` anlegen
2. `index.html` mit DkZ Design System erstellen
3. `features.json` mit Modul-Metadaten erstellen
4. `REGISTRY.json` aktualisieren (neue MOD-ID)
5. `BLAUPAUSE.md` aktualisieren (Ordnerbaum + Kategorie)
6. Git commit

### DkZ Design System
- **Akzentfarbe:** `#fa1e4e` (Neonrot) � IMMER Prim�rfarbe
- **Background:** `#0e0e10` (Dark)
- **Fonts:** Inter + JetBrains Mono (Google Fonts CDN)
- **Glassmorphism:** `backdrop-filter: blur(24px)`
- **Jedes Modul hat:** `? Hub` Button, Toast, v0.01 im Header

### features.json Pflichtfelder
- `id`: MOD-XXX Format
- `name`: Modulname
- `version`: "0.01"
- `description`: Was das Modul macht
- `features[]`: Array mit `name` + `status` (done/wip/planned)

---

## ? KONFLIKT-WARNSYSTEM

Wenn eine Aktion Konflikte verursachen k�nnte:

| Situation | Aktion |
|:---|:---|
| Datei �berschreiben | ?? WARNEN � Backup erstellen, dann fragen |
| Modul entfernen | ?? WARNEN � Nur archivieren, nie l�schen |
| REGISTRY.json �ndern | ?? Pr�fen ob IDs kollidieren |
| Gro�e Umstrukturierung | ?? Plan erstellen, User-Genehmigung einholen |
| Unbekanntes Format | ?? WARNEN � in RAW/archive ablegen |

---

## ?? CHECKLISTE F�R JEDEN ARBEITSBEGINN

- [ ] `REGELWERK.md` gelesen
- [ ] `04_SYSTEM/claude.md` gelesen  
- [ ] Aktuelle REGISTRY.json Modulzahl gepr�ft
- [ ] Git Status gepr�ft (`git status` � clean?)
- [ ] Letzte Commits gepr�ft (`git log -n 5`)

---

## ?? LLM OUTPUT-REFERENZ � So wird gearbeitet

> **F�r jedes LLM / jeden Agent:** Verwende genau diese Formate.
> Hier sind Beispiele mit echtem Code, die du 1:1 �bernehmen kannst.

---

### ?? Beispiel: features.json (EXAKT so erstellen)

```json
{
  "id": "MOD-056",
  "name": "Beispiel Tool",
  "version": "0.01",
  "description": "Kurze Beschreibung was das Modul macht",
  "category": "data",
  "ui": "vanilla",
  "design": {
    "framework": "DkZ Design System v2",
    "theme": "dark/light",
    "accentColor": "#fa1e4e",
    "responsive": true
  },
  "code": {
    "structure": "modular",
    "files": ["index.html"],
    "inlineCSS": true,
    "inlineJS": true,
    "localStorage": "dkz-beispiel"
  },
  "features": [
    { "name": "Feature Eins", "status": "done" },
    { "name": "Feature Zwei", "status": "wip" },
    { "name": "Feature Drei", "status": "planned" }
  ],
  "issues": [],
  "origin": "DEVKiTZ"
}
```

---

### ?? Beispiel: index.html Modul-Grundger�st (EXAKT so starten)

```html
<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>?? Beispiel Tool � DkZ v0.01</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=JetBrains+Mono&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #0e0e10;
      --card: #1a1a1c;
      --card2: #222226;
      --border: #333338;
      --text: #f6f6f7;
      --muted: #a1a1aa;
      --accent: #fa1e4e;
      --green: #00ff88;
      --blue: #55ACEE;
      --yellow: #FFB800;
      --radius: 14px;
      --glass: rgba(26,26,28,0.7);
    }
    * { margin:0; padding:0; box-sizing:border-box; }
    body {
      font-family: 'Inter', sans-serif;
      background: var(--bg);
      color: var(--text);
      min-height: 100vh;
    }
    /* Glassmorphism Header */
    .header {
      position: sticky; top: 0; z-index: 100;
      display: flex; align-items: center; justify-content: space-between;
      padding: 12px 24px;
      background: var(--glass);
      backdrop-filter: blur(24px);
      border-bottom: 1px solid var(--border);
    }
    .header a { color: var(--accent); text-decoration: none; }
    .header h1 { font-size: 1.1rem; }
    .header .version { color: var(--muted); font-size: 0.85rem; }
    /* Background Blobs */
    .blob {
      position: fixed; border-radius: 50%;
      filter: blur(120px); opacity: 0.15; pointer-events: none;
    }
    .blob-1 { width:400px; height:400px; background:var(--accent); top:-100px; right:-100px; }
    .blob-2 { width:300px; height:300px; background:var(--blue); bottom:-50px; left:-50px; }
    /* Cards */
    .card {
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 20px;
      margin: 16px 24px;
    }
    /* Buttons */
    .btn {
      background: var(--accent);
      color: white; border: none;
      padding: 10px 20px;
      border-radius: 8px; cursor: pointer;
      font-weight: 600; font-family: 'Inter', sans-serif;
      transition: box-shadow 0.2s;
    }
    .btn:hover { box-shadow: 0 0 20px rgba(250,30,78,0.4); }
    /* Toast */
    .toast {
      position: fixed; bottom: 24px; right: 24px;
      background: var(--green); color: #000;
      padding: 12px 24px; border-radius: 8px;
      font-weight: 600; transform: translateY(100px);
      transition: transform 0.3s;
    }
    .toast.show { transform: translateY(0); }
  </style>
</head>
<body>
  <div class="blob blob-1"></div>
  <div class="blob blob-2"></div>

  <header class="header">
    <a href="../hub/">? Hub</a>
    <h1>?? Beispiel Tool</h1>
    <span class="version">v0.01</span>
  </header>

  <main>
    <div class="card">
      <h2>Funktionsbereich</h2>
      <!-- INHALT HIER -->
    </div>
  </main>

  <div class="toast" id="toast">? Aktion erfolgreich!</div>

  <script>
    function showToast(msg, ms = 2500) {
      const t = document.getElementById('toast');
      t.textContent = msg;
      t.classList.add('show');
      setTimeout(() => t.classList.remove('show'), ms);
    }

    function esc(s) {
      const d = document.createElement('div');
      d.textContent = s;
      return d.innerHTML;
    }
  </script>
</body>
</html>
```

---

### ?? Beispiel: Analyse-Report (Markdown-Format)

```markdown
# Analyse: [Modul-Name]

## Zusammenfassung
| Metrik | Wert |
|:---|:---|
| Dateien | 3 |
| Zeilen Code | 1.250 |
| Features | 8 done, 2 wip, 1 planned |
| Issues | 2 (1 kritisch, 1 niedrig) |
| XSS-sicher | ? Ja |
| localStorage | ? Ja |

## Gefundene Probleme

| # | Schwere | Beschreibung | Zeile | Fix |
|---|:---:|:---|:---:|:---|
| 1 | ?? | XSS in innerHTML | L245 | `textContent` verwenden |
| 2 | ?? | Fehlende Validierung | L180 | try-catch hinzuf�gen |

## Empfehlungen
1. esc() Funktion gegen escapeHTML() tauschen
2. localStorage Overflow-Handling einbauen
3. Keyboard Shortcuts dokumentieren
```

---

### ??? Beispiel: Mindmap (Text-basiert)

```
                        +------------------+
                        �    DEVKiTZ       �
                        �   �kosystem      �
                        +------------------+
                                 �
          +----------------------+----------------------+
          �                      �                      �
    +------------+        +------------+        +------------+
    � 01_PROJECTS �        � 04_SYSTEM  �        � 99_ARCHIVE �
    � 12 Projekte �        � Configs    �        � Archiv     �
    +------------+        +------------+        +------------+
          �                      �
     +---------+           +---------+
     �Dashboard�           �claude.md�
     �55 Module�           �REGELWERK�
     +---------+           +---------+
```

---

### ?? Beispiel: Ordnerstruktur-Plan (f�r Umstrukturierung)

```
VORHER:                              NACHHER:
------------                         ------------
root/                                root/
  +-- loses-dokument.md    --?         +-- 00_INBOX/unsorted/loses-dokument.md
  +-- privat-datei.docx    --?         +-- 05_INTERN/privat/privat-datei.docx
  +-- altes-projekt/       --?         +-- 99_ARCHIVE/altes-projekt/

REGEL: Pfeile zeigen Verschiebung, NICHTS wird gel�scht!
```

---

### ?? Beispiel: Git Commit Messages

```bash
# ? RICHTIG:
git commit -m "feat(suno-ai): add playlist export feature v0.01"
git commit -m "fix(gallery): XSS vulnerability in search input"
git commit -m "docs: update BLAUPAUSE.md � 55 modules"
git commit -m "chore: move loose files to 00_INBOX/unsorted/"
git commit -m "style(doc-engine): apply DkZ v2 accent color"
git commit -m "refactor(markdown-gen): replace innerHTML with textContent"

# ? FALSCH:
git commit -m "update"
git commit -m "fix stuff"
git commit -m "changes"
git commit -m "wip"
```

---

### ?? Beispiel: REGISTRY.json Eintrag hinzuf�gen

```json
// In REGISTRY.json ? tree Objekt hinzuf�gen:
"modules/neues-modul": {
    "features": "modules/neues-modul/features.json",
    "type": "module",
    "id": "MOD-056"
}

// In meta ? totalModules hochz�hlen:
"totalModules": 56
```

---

### ?? Beispiel: Tabellen-Formate

**Modul-�bersicht:**
```markdown
| ID | Modul | Status | Features | Issues |
|:---|:---|:---:|:---:|:---:|
| MOD-053 | doc-engine | ? aktiv | 11 | 1 |
| MOD-054 | domain-control | ? aktiv | 6 | 0 |
| MOD-055 | llm-cost-board | ? aktiv | 4 | 0 |
```

**Datei-Inventar:**
```markdown
| # | Datei | Typ | Gr��e | Aktion |
|---|:---|:---|:---|:---|
| 1 | index.html | HTML | 45 KB | Bearbeiten |
| 2 | app.js | JS | 33 KB | Pr�fen |
| 3 | style.css | CSS | 8 KB | OK |
```

**Vergleichs-Tabelle:**
```markdown
| Kriterium | Option A | Option B | Empfehlung |
|:---|:---|:---|:---:|
| Kompatibilit�t | ? Hoch | ?? Mittel | A |
| Performance | ?? Mittel | ? Hoch | B |
| Wartbarkeit | ? Hoch | ? Hoch | = |
```

---

### ?? Beispiel: Workflow-Dokumentation

```markdown
## Workflow: Neues Modul integrieren

### Schritt 1: Analyse
- [ ] Dateien scannen und Typ identifizieren
- [ ] Kompatibilit�t mit DkZ Design System pr�fen
- [ ] features.json Inhalte planen

### Schritt 2: Integration
- [ ] Ordner `modules/modul-name/` erstellen
- [ ] index.html mit DkZ Template erstellen
- [ ] features.json erstellen (MOD-XXX)
- [ ] Git: `git add -A; git commit -m "feat(modul-name): initial module v0.01"`

### Schritt 3: Registrierung
- [ ] REGISTRY.json ? neuer Eintrag + totalModules++
- [ ] BLAUPAUSE.md ? Ordnerbaum + Kategorie erg�nzen
- [ ] Git: `git add -A; git commit -m "docs: register modul-name in REGISTRY + BLAUPAUSE"`

### Schritt 4: Verifikation
- [ ] `git grep "modul-name"` ? in REGISTRY und BLAUPAUSE?
- [ ] Browser-Test: index.html �ffnen
- [ ] features.json valides JSON?
```

---

### Regel 24: ARCHIV-SCHUTZ � EISERNE REGEL
> **?? KEIN LLM / Agent / Script darf Dateien ins Archiv verschieben ohne explizite Best�tigung durch 777.**
>
> **Ausl�ser f�r Alarm:**
> - Datei wird in `99_ARCHIVE/` oder `99_archived/` verschoben
> - Datei wird umbenannt mit `_LEGACY_` Pr�fix
> - Verzeichnis wird geleert oder zusammengef�hrt
> - Modul wird aus REGISTRY.json entfernt
>
> **Alarm-Protokoll (James-Pflicht):**
> 1. `?? ARCHIV-ALARM` auf JEDEM aktiven Dashboard anzeigen
> 2. Log-Eintrag mit Zeitstempel, Datei, und Grund
> 3. Aktion BLOCKIEREN bis 777 best�tigt
> 4. Bei unautorisierten Verschiebungen: SOFORT r�ckg�ngig machen
>
> **Warum:** Wertvolle Arbeit wurde ohne Wissen des Eigent�mers archiviert.
> Das darf NIE WIEDER passieren. Archivierung ist eine 777-Entscheidung.

### Regel 25: NAMING CONVENTION � Offizielle Produkt-Namen�
> Alle Produkte, Projekte und Tools haben **offizielle Namen** mit stilvoller Gro�-/Kleinschreibung.
> Bei Nennung IMMER das � Symbol verwenden (mindestens bei Erstnennung pro Dokument).
>
> **Regeln:**
> - **Hybrid-Naming** erlaubt: `ProduktName_Variante_vX` (z.B. `FlyerPRO_Tauri_v2`)
> - **Varianten** statt Versionen bei �hnlichen Projekten
> - Gro�-/Kleinschreibung hat **Style** � keine generischen Namen
>
> **Offizielle Naming-Liste�:**
>
> | Name� | Typ | Beschreibung |
> |:------|:----|:-------------|
> | DEVKiTZ� | �kosystem | Gesamtes Entwickler-�kosystem |
> | DkZ� | Dashboard | Dashboard + 72 Module |
> | OpenClaw� | Orchestrator | Multi-Agent Orchestrator |
> | PicoClaw� | Agent | Frontend-Spezialist |
> | BotNet� | Marketplace | Agent-Marktplatz + DAC |
> | James� | Master-Agent | GPT Evaluator + Guardian |
> | AiAiKirk� | KI-Assistent | Podcast + Voice AI |
> | FlyerPRO� | Builder | Flyer/Design Tool (Tauri/React) |
> | FlyerEngine� | Template | Flyer Template Engine |
> | DocEngine� | Wiki | Wiki-Builder + i18n |
> | DataLakeHouse� | Daten | Apache Iceberg + DuckDB |
> | ONTHERUN� | MCP Server | Model Context Protocol Gateway |
> | WhisperBar� | Voice | Speech-to-Text Integration |
> | NEXUZ� | Gateway | API Gateway + Middleware |
> | DEEPKEEP� | Archiv | GitHub + AI Chat Backup |
> | AutoPilot� | Hub | Python + SQLite Automation |
> | PromptBuilder� | Tool | Prompt Engineering Suite |
> | ICEberg� | Monitor | System-�berwachung |

### Regel 26: WISSENHUB ARCHIV-PFLICHT � JEDE SESSION, JEDER AGENT
> **Jede KI-Session (Antigravity, Claude, Gemini) MUSS erstelltes Wissen automatisch ins WissenHub archivieren.**
>
> **Was wird archiviert (4 Rubriken):**
>
> | Rubrik | Symbol | Dateityp |
> |:---|:---|:---|
> | Implementierungsplan | ?? | `impl_[timestamp]_[titel].md` |
> | Walkthrough | ?? | `walk_[timestamp]_[titel].md` |
> | Research | ?? | `research_[timestamp]_[titel].md` |
> | Task | ? | `task_[timestamp]_[titel].md` |
>
> **Archiv-Pfad:** `01_PROJECTS/01_dashboard/modules/wissen-hub/archive/[rubrik]/`
>
> **Katalog:** `modules/wissen-hub/archive/catalog.json` � Apache Iceberg Manifest
>
> **Eiserne Archiv-Regeln:**
> - ? **KEIN L�SCHEN** � Daten sind immutable (wie Iceberg Snapshots)
> - ? **KEIN MANUELLES UPLOAD** � nur KI-Agenten schreiben ins Archive
> - ? Jeder Eintrag bekommt: `snapshot_id`, `timestamp`, `source` (welcher Agent)
> - ? `catalog.json` wird bei jedem neuen Eintrag aktualisiert
> - ? Die `index.html` des WissenHub zeigt ALLE Eintr�ge �ber DuckDB-Query + JAMEZ� Suche
>
> **Wann archivieren:**
> - Bei JEDER Anfrage in JEDEM Chat
> - Egal ob DEVKiTZ-Kontext oder freier Chat
> - Egal welche Plattform (Antigravity, Claude, Gemini, andere)
>
> **Interface:** `file:///C:/DEVKiTZ/01_PROJECTS/01_dashboard/modules/wissen-hub/index.html`
>
> **Warum:** Wissen ist das h�chste Gut. Jede KI-Interaktion produziert Wissen.
> Dieses Wissen MUSS zentral, durchsuchbar und unverlierbar gespeichert werden.


---

### ?? Beispiel: CSS-Variablen Referenz (Kopier-fertig)

```css
/* DkZ Design System v2 � Vollst�ndige Variablen */
:root {
  /* Hintergr�nde */
  --bg: #0e0e10;
  --card: #1a1a1c;
  --card2: #222226;
  --glass: rgba(26,26,28,0.7);
  
  /* R�nder & Schatten */
  --border: #333338;
  --radius: 14px;
  --shadow: 0 4px 24px rgba(0,0,0,0.3);
  
  /* Text */
  --text: #f6f6f7;
  --muted: #a1a1aa;
  
  /* Farben */
  --accent: #fa1e4e;     /* Neonrot � IMMER Prim�r */
  --green: #00ff88;      /* Erfolg */
  --blue: #55ACEE;       /* Info, Links */
  --yellow: #FFB800;     /* Warnung */
  
  /* Fonts */
  --font-ui: 'Inter', sans-serif;
  --font-mono: 'JetBrains Mono', monospace;
}
```

---

## ?? �NDERUNGSPROTOKOLL

| Datum | Was | Wer |
|:---|:---|:---|
| 2026-03-10 | v1.0 � Erstellt mit 9 Regeln + LLM Output-Referenz | Antigravity |
| 2026-03-11 | v1.05 � R21 Shared Scripts, R22 Features.json, R23 Go?Python Fallback + 59 Module | Antigravity |
| 2026-03-11 | v1.06 � R24 ARCHIV-SCHUTZ (eiserne Regel), R25 NAMING CONVENTION (� Liste) | Antigravity |

---

*Dieses Dokument wird bei jeder neuen Regel sofort aktualisiert.*
*Jedes LLM das an DEVKiTZ arbeitet MUSS dieses Dokument vor Beginn lesen.*


---

### R101 � GitHub Push PFLICHT
- Nach JEDER Session: `git push origin master` ausfuehren
- Push-Ergebnis PRUEFEN � muss `->` zeigen, nicht Error
- Wenn Push fehlschlaegt: SOFORT melden, NICHT weiterarbeiten
- GitHub-Repo MUSS existieren bevor Code-Aenderungen beginnen
- Bei Session-Start: `git remote -v` pruefen, `git push --dry-run` testen
- REGEL: Keine Arbeit ohne funktionierenden GitHub Push!
---

### Regel 27: WORKFLOW-FIRST PRINZIP (R35)

> **JEDE neue Funktion wird ERST als Skill/Workflow gespeichert, DANN ausgefÃ¼hrt.**

**Ablauf:**
1. **SKILL erstellen** â†’ `.agents/skills/[name]/SKILL.md` mit Syntax + Anleitung
2. **WORKFLOW erstellen** â†’ `.agents/workflows/[name].md` mit Schritt-fÃ¼r-Schritt
3. **WORKFLOW ausfÃ¼hren** â†’ `/workflow/[name]` Ã¶ffnen und automatisch durchlaufen
4. **TESTEN** â†’ Browser-Test, Screenshots/Video speichern
5. **FEHLER DOKUMENTIEREN** â†’ Bugs im Workflow/Skill korrigieren mit getesteter Anweisung

**NIEMALS:**
- Befehle aus dem Kopf ausfÃ¼hren ohne Workflow
- Fehlgeschlagene Befehle wiederholen ohne den Workflow zu korrigieren
- Workflows ohne Test-Nachweis (Screenshot/Video) committen

### Regel 28: NLM CONTENT-PIPELINE (R31)

> **PFLICHT bei neuem Projekt/Feature:** MINDESTENS Report + Slides + Audio (DE) generieren.

- **CLI:** `nlm` v0.5.2+ in `C:\Users\BAZEÂ²\.local\bin\`
- **Workflow:** `.agents/workflows/notebooklm.md`
- **Syntax:** `.agents/skills/notebooklm-integration/NLM-SYNTAX.md`
- **Sprache:** IMMER `--language de` bei Audio
- **Brand:** "DkZ" statt "DEVKiTZ" in Medien (`DkZ-Brand.md`)
- **Eingliedern:** WissenHub `catalog.json` + `archive/[rubrik]/`

### Regel 29: DkZ BRAND IN MEDIEN (R33)

> **Markenname in Audio/Video/Slides:** Immer "DkZ", nie "DEVKiTZ"

- **Audio (WAV/MP3):** DkZ
- **Video (MP4):** DkZ
- **Slides/PDF:** DkZ in Titel + Footer
- **Infografiken:** DkZ Watermark
- **Standard-Sprache:** Deutsch

### Regel 30: VORSCHAU-ORDNER PFLICHT (R34)

> **Bei JEDEM Chat-Ende:** Browser-Test durchfÃ¼hren und alles sichern.

```
modul-ordner/
+-- Vorschau/
|   +-- clips/          <- Kurze GIF/WebP Clips
|   +-- screenshots/    <- Test-Screenshots + Metadata
|   +-- recordings/     <- Vollstaendige Test-Recordings
+-- docs/
|   +-- research/       <- Deep Dive Daten
|   +-- chatlog/        <- Projekt-Chatlog
|   +-- metadata/       <- JSON Metadaten
```



## R31 — Wiki Hub Auto-Sync (PFLICHT)

- `wiki-hub-sync-data.js` muss IMMER existieren
- Git Pre-Commit Hook generiert sie automatisch
- Bei manuellem Sync: `generate-sync-data.ps1` ausfuehren
- KERN2-Dateien duerfen NIEMALS geloescht werden

---

## R32 — CONTEXT-WINDOW MANAGEMENT (HAUPTREGEL)

> **Bei JEDEM neuen Auftrag / neuer Task-Session MUSS das Context-Fenster geprueft werden.**

**Ablauf:**
1. **Context-Fenster pruefen** — wie viel % sind belegt?
2. **Ab 66,6% Belegung → KOMPLETT LEEREN** (neue Session starten)
3. **Frischen Kontext laden** aus vorbereiten Leitfaden-Dateien:

| Prioritaet | Datei | Zweck |
|:-----------|:------|:------|
| 1 | `GEMINI.md` | Projekt-Gedaechtnis, Tech-Stack, Regeln |
| 2 | `REGELWERK.md` | Alle Regeln (dieses Dokument) |
| 3 | `BLAUPAUSE.md` | Architektur, Modulstruktur |
| 4 | `AGENTS.md` | Agenten-Learnings, Kulturelles Wissen |
| 5 | `CLAUDE.md` | Claude-spezifisches Gedaechtnis |
| 6 | `DKZ_RULES.md` | Antigravity-spezifische Kurzregeln |

**Warum:**
- Voller Context = Context Drift = Halluzinationen
- Fresh Context = Praezise Antworten = Bessere Ergebnisse
- Ralph-Loop Prinzip: JEDER Task bekommt frischen Kontext
- Die Leitfaden-Dateien enthalten ALLES was noetig ist

**NIEMALS:**
- Bei vollem Context weiterarbeiten ohne zu leeren
- Ohne Leitfaden-Dateien starten (blinder Kontext)
- Alten Context aus vorherigen Tasks mitschleppen

---

## R33 — KI-TOOLING & FRAMEWORK-INTEGRATION

> **Folgende Tools und Frameworks sind im Oekosystem verankert und MUESSEN wo moeglich eingesetzt werden:**

### Orchestrierung & Agenten
| Tool | Zweck | Status |
|:-----|:------|:-------|
| **OpenClaw™** | Multi-Agent Orchestrator, Self-Hosting | ✅ Aktiv (Token konfiguriert) |
| **PicoClaw™** | Frontend Micro-Agents (8 Claws) | ✅ v2.0 (`dkz-picoclaw.js`) |
| **Google A2A** | Agent-to-Agent Protocol | 🔄 Integration geplant |
| **Google Agent Framework** | Google ADK fuer Agent-Entwicklung | 🔄 Integration geplant |
| **BMAD™** | 7-Agenten Methodik | ✅ Aktiv |

### Code-Qualitaet & Review
| Tool | Zweck | Regel |
|:-----|:------|:------|
| **CodeRabbit** | AI Code Review | ✅ UEBERALL einsetzen wo Code geprueft wird |
| **Caffe** | Deep Learning Framework (BVLC + NVIDIA) | 🔄 Fuer ML/Vision Tasks |

### LLM Model Routing (Kosten-Optimierung)
| Tier | Einsatz | Beispiel-Modelle | Kosten |
|:-----|:--------|:-----------------|:-------|
| **Flash** | Heartbeat, Routing, Suche | Gemini Flash, GPT-4.1-nano, Haiku | ~$0.01/1M |
| **Standard** | Chat, Lint, SEO, OCR | GPT-4.1-mini, DeepSeek-Coder | ~$0.05/1M |
| **Premium** | Code-Gen, Architektur, Reasoning | Claude Opus, GPT-4.5 | ~$1.50/1M |

**Kernregel:** 80% der Tasks mit Flash/Standard-Modellen → 60-90% Kosten sparen.
**Router-UI:** `modules/neural-swarm/` → Tab "LLM Model Router"

### Auto-Research Pflicht
> Bei messbaren Ergebnissen (Performance, Kosten, Qualitaet) IMMER:
> 1. Baseline messen (vorher)
> 2. Aenderung durchfuehren
> 3. Ergebnis messen (nachher)
> 4. Delta dokumentieren in WissenHub
> 5. Bei Verbesserung > 10%: Automatisch als Best Practice verankern

---

## R34 — LLMS.TXT PFLICHT (Quellcode-Identifikation)

> **JEDE Website, App oder Produktion MUSS eine `llms.txt` Datei im Root haben.**

**Was ist llms.txt:**
Eine standardisierte Datei (wie `robots.txt`) die LLMs erklaert, was die Seite/App ist, wie sie funktioniert, und welche APIs verfuegbar sind.

**Pflicht-Inhalt:**

```text
# DEVKiTZ™ [Modul-Name]
> [Kurzbeschreibung]

## Docs
- [Link zu Dokumentation]

## API
- [Verfuegbare Endpunkte/Schnittstellen]

## Tech Stack
- Vanilla HTML5 + CSS3 + JavaScript ES6+
- DkZ Design System v2 (#fa1e4e Accent)
- No Frameworks (React/Vue/Angular VERBOTEN)

## Contact
- Owner: 777
- Repo: github.com/777/devkitz-ecosystem
```

**Regeln:**
- Bei JEDEM neuen Modul/Projekt automatisch erstellen
- Bei JEDER Deployment/Produktion vorhanden
- Einzige Ausnahme: User sagt ausdruecklich "llms.txt weglassen"
- Auch als Meta-Tag im HTML: `<meta name="llms" content="/llms.txt">`

---

## R35 — COMFYUI VISUAL PIPELINE (PLUS MODE)

> **Alle Builder-Module MUESSEN den ComfyUI-Style Node-Editor als PLUS MODE anbieten.**

**Betroffene Module:**

| Modul | Node-Typ | Beschreibung |
|:------|:---------|:-------------|
| `workflow-builder` | Workflow-Nodes | n8n-Style Workflow-Ketten |
| `workflow-viewer` | Read-Only | Workflow-Visualisierung |
| `agent-builder` | Agent-Nodes | Agenten zusammenstellen |
| `agent-viewer` | Agent-Graph | Agent-Beziehungen anzeigen |
| `loop-builder` | Loop-Nodes | Ralph-Loop Phasen definieren |
| `team-builder` | Team-Graph | BMAD Teams zusammenstellen |
| `n8n-builder` | n8n-Nodes | n8n-kompatible Workflows |

**PLUS MODE Features:**
- **Node-Editor:** Drag & Drop Knoten mit Verbindungslinien
- **Palette:** Seitenleiste mit verfuegbaren Node-Typen
- **Canvas:** Zoom/Pan mit Mausrad + Drag
- **Ports:** Input/Output Ports fuer Datenfluss
- **SmartLook:** Live-Vorschau der Node-Ausgangs-Daten
- **Export:** JSON-Export der Node-Konfiguration
- **Design:** DkZ Dark Theme, Glassmorphism, Glow-Effekte

**ComfyUI Installation:** `01_PROJECTS/ComfyUI/` (Python Backend fuer Bild-Generierung)

**SmartLook Integration:** Session-Recording fuer UX-Analyse der Builder-Nutzung

---

## R36 — PYTHON AI STACK (Installation + Verwaltung)

> **Folgende Python-Pakete gehoeren zum Oekosystem:**

| Paket | Zweck | Status | Settings-Flag |
|:------|:------|:-------|:-------------|
| `torch` + CUDA | Deep Learning Runtime | ✅ Installiert (nightly/cu128) | Aktiv |
| `keras` | High-Level Neural Network API | ✅ Installiert | Aktiv |
| `google-adk` | Google Agent Development Kit | ✅ Installiert | Aktiv |
| `langchain` | LLM Chain Framework | ✅ Installiert | ❌ DEAKTIVIERT |
| `comfyui` | Bild-Generierung Pipeline | ✅ Geklont | Aktiv |
| `opencode` | AI Coding CLI (Terminal) | ✅ npm installiert | Aktiv |

**LangChain Sonderregel:**
- Installiert aber NICHT aktiv (in Settings: `langchain_enabled: false`)
- Kann ueber Settings aktiviert werden wenn benoetigt
- Grund: Overhead + Abhaengigkeiten, nur bei Bedarf

**Keras + Google Agent Framework:**
- Keras als Haupt-API fuer ML/DL auf PyTorch Backend
- Google ADK als Agent-Entwicklungsframework (A2A kompatibel)
- Verbindung: Keras → PyTorch → CUDA (RTX 2060 SUPER 8GB)

---

## R37 — NANOCHAT (Leichtgewichtiger Flash-Chat)

> **NanoChat = minimaler Chat der NUR Flash/Nano-Modelle nutzt (Kosten: ~$0.01/1M Tokens)**

**Einsatzgebiete:**
- Heartbeat-Checks und Ping-Antworten
- Einfache Klassifizierungen und Routing
- Quick-Lookups in der Wissensbasis
- Status-Reports generieren
- Uebersetzungen und Zusammenfassungen

**Standard-Modelle fuer NanoChat:**
- `gemini-2.0-flash-lite` (Primaer)
- `gpt-4.1-nano` (Fallback)
- `claude-haiku-3.5` (Alternative)

**Integration:** Konfigurierbar im Neural Swarm → LLM Model Router
**API:** `PICOCLAW.restChat(prompt, { model: 'nano' })` nutzt automatisch das guenstigste Modell

---

## R38 — PREMIUM DESIGN STANDARD (Eiserne Regel)

> **JEDE Oberflaeche MUSS hochwertig aussehen. Kein MVP, kein Platzhalter, kein "reicht erstmal".**

**Pflicht-Elemente:**
- DkZ Dark Theme (`--bg: #060608`, `--accent: #fa1e4e`)
- Glassmorphism Header + Cards (`backdrop-filter: blur(20px)`)
- Background Blobs (min. 2, gradient, `pointer-events: none`)
- Micro-Animations (Hover, Transitions, `transform: translateY(-2px)`)
- Toast-Benachrichtigungen bei Aktionen
- Inter + JetBrains Mono Fonts (Google Fonts)
- Responsive (Desktop + Tablet + Mobile)
- `esc()` bei jedem User-Input (XSS-Schutz)

**Settings-Personalisierung:**
- Accent-Farbe aenderbar (Default: `#fa1e4e`)
- Font-Groesse skalierbar
- Animation-Geschwindigkeit einstellbar
- Compact/Komfortabel Modus
- Helle/Dunkle Variante (Dark = Standard)

**NIEMALS:**
- Einfarbige Hintergründe ohne Gradient
- Standard-Browser-Fonts
- Fehlende Hover-Effekte
- Sichtbare Lade-Ruckler

---

## R39 — DEUTSCHE UMLAUTE PFLICHT (ö, ä, ü, ß)

> **Ab sofort IMMER echte Umlaute schreiben — KEINE ASCII-Ersetzungen mehr.**

| Richtig ✅ | Falsch ❌ |
|:----------|:---------|
| ö, ä, ü, ß | oe, ae, ue, ss |
| Änderung | Aenderung |
| Übersicht | Uebersicht |
| Größe | Groesse |
| für | fuer |

**Gilt für:**
- Code-Kommentare
- Dokumentation (REGELWERK, GEMINI.md, CLAUDE.md, etc.)
- Content und Texte jeder Art
- Git Commit Messages (Deutsch)
- UI-Labels und Beschreibungen

**Einzige Ausnahme:**
- Dateinamen bleiben ASCII-kompatibel (kein ö/ä/ü in Dateinamen)
- Variablen-Namen im Code bleiben englisch/ASCII

---

## R40 — AGENT-TESTING & WISSENSHUB-FEED (PFLICHT)

> **Am Ende JEDER Session: Mit Agenten als User testen und Mitschnitte ins WissenHub einspeisen.**

**Ablauf:**
1. **Browser-Test** — Modul/Feature im Browser öffnen und durchklicken
2. **Recording erstellen** — Screenshots + WebP-Video der Test-Session
3. **Ergebnis dokumentieren** — Was funktioniert, was nicht
4. **WissenHub füttern** — Mitschnitt + Ergebnis als Walkthrough archivieren:
   - Pfad: `modules/wissen-hub/archive/walkthrough/`
   - Format: `walk_[timestamp]_[titel].md`
   - Screenshots einbetten: `![Beschreibung](pfad/zum/screenshot.png)`
   - Recording einbetten: `![Recording](pfad/zum/recording.webp)`
5. **Catalog aktualisieren** — `catalog.json` um neuen Eintrag ergänzen

**WissenHub = Ökosystem-Unterlagen:**
- ALLE Test-Ergebnisse werden zentral gesammelt
- Durchsuchbar über WissenHub-Interface
- Immutable — kein Löschen
- Jeder Agent hat Lesezugriff für zukünftige Sessions

**Warum:**
- Reproduzierbare Qualitätssicherung
- Jede Session hinterlässt messbaren Nachweis
- Wissen über funktionierende/nicht-funktionierende Features wächst automatisch
- Nächste Session kann sofort sehen was zuletzt getestet wurde

---

## R41 — SELF-LEARNING SYSTEM (dkz-self-learn.js)

> Universelles Bewertungs- und Lernsystem für das gesamte Ökosystem.
> Überall wo bewertbare Outputs entstehen MUSS ein Rating-Widget eingebunden werden.

### Shared Script: `shared/dkz-self-learn.js`

**API:**
```javascript
// Bewerten (1-5 Sterne)
DkzLearn.rate('model-routing', 'codegen:claude-sonnet-4', 5, { model:'claude-sonnet-4', taskType:'codegen' });

// Durchschnitt abrufen
DkzLearn.getScore('prompt-quality', 'prompt-123');  // → { avg: 4.2, count: 7 }

// Top / Worst abfragen
DkzLearn.getBest('model-routing', 5);   // Top 5
DkzLearn.getWorst('agent-response', 3); // Worst 3

// KI-optimierte Empfehlung
DkzLearn.suggest('model-routing');       // Gewichtete Zufallsauswahl

// Bestes Modell für Task-Typ
DkzLearn.suggestModel('codegen');        // → { model:'claude-sonnet-4', score:4.8 }

// Widget einfügen (CSS-Sterne, interaktiv)
DkzLearn.injectWidget('#container', 'prompt-quality', 'prompt-123', { size:'small' });

// Dashboard-Statistiken
DkzLearn.dashboard();                    // → { totalRatings, categories, topModels }
```

### 12 Bewertungs-Kategorien (PFLICHT):

| Kategorie | Wo eingebunden | Was wird bewertet |
|:----------|:---------------|:------------------|
| `model-routing` | Neural Swarm, LLM Router | Modell-Auswahl pro Task |
| `prompt-quality` | Prompt Hub, Prompt Generator | Prompt-Ergebnis-Qualität |
| `agent-response` | AI Chat, Copilot | Agenten-Antwort Qualität |
| `code-output` | Builder Module, Code-Gen | Generierter Code |
| `workflow-run` | Loop Dashboard, Workflows | Workflow-Ergebnis |
| `builder-output` | Alle Builder (App, Workflow, etc.) | Builder-Output Qualität |
| `search-result` | WissenHub, Wiki Hub, Search | Such-Relevanz |
| `james-review` | James Panel | James-Bewertungs-Genauigkeit |
| `translation` | Übersetzer-Module | Übersetzungs-Qualität |
| `summary` | Zusammenfassungs-Module | Zusammenfassungs-Qualität |
| `design-output` | Design-Module, CSS Generator | Design-Output Qualität |
| `data-analysis` | Iceberg, Analytics | Analyse-Ergebnis Qualität |

### Integration in Module (PFLICHT bei bewertbaren Outputs):

```javascript
// Shared Script laden (portable)
<script src="../../shared/dkz-self-learn.js"></script>

// Widget nach Output einfügen
DkzLearn.injectWidget('#output-container', 'code-output', 'task-' + Date.now(), {
    size: 'medium',
    meta: { model: 'claude-sonnet-4', module: 'app-builder' }
});
```

### Model-Routing Feedback-Loop:

```
User bewertet Output → DkzLearn.rate()
     ↓
Score in localStorage → modelScores aktualisiert
     ↓
Nächste Anfrage → DkzLearn.suggestModel(taskType)
     ↓
Bestes Modell wird vorgeschlagen → Kosten sinken, Qualität steigt
```

### OpenClaw — NUR Gateway-Anbindung:

- OpenClaw erhält Bewertungs-Events via `dkz:learn:rated` CustomEvent
- `PICOCLAW.restInvoke('self-learn-sync', data)` — Silenter Sync
- OpenClaw speichert NICHT selbst — NUR als Weiterleitung
- Self-Learning Logik liegt KOMPLETT im Ökosystem (localStorage)

### Speicher:

- **localStorage:** `dkz-self-learn` — Ratings, Insights, Model-Scores, Prompt-Patterns
- **Rolling Window:** Max 100 Ratings pro Item (älteste werden verworfen)
- **Export/Import:** `DkzLearn.exportData()` / `DkzLearn.importData(data)`
- **Archiv:** WissenHub für langfristige Analyse

### NIEMALS:

- Self-Learning in OpenClaw direkt implementieren → NUR Gateway
- Rating-Widgets weglassen wenn Output bewertbar ist
- Manuell Model-Scores setzen → nur durch User-Bewertung
- localStorage-Keys umbenennen → `dkz-self-learn` ist fix

---

## R42 — ESC-CONSOLE (Universelles CLI-Panel)

> **Pflicht:** Jedes Modul im Ökosystem hat eine ESC-Console am unteren Rand.
> Shortcut: `ESC` oder `Ctrl+`` = Toggle

### Shared Script

- **Datei:** `shared/dkz-console.js`
- **Version:** v1.0.0
- **Global API:** `window.DkzConsole`
- **Injection:** Automatisch via IIFE — kein manuelles DOM nötig
- **CSS:** Selbst-injizierend (kein extra Stylesheet)

### 8 Tabs (PFLICHT)

| Tab | Prompt | CLI | Farbe | Beschreibung |
|:----|:-------|:----|:------|:-------------|
| Terminal | `PS>` | powershell | `#00ff88` | Shell-Emulation (Browser-limitiert) |
| Gemini CLI | `gemini>` | gemini | `#4285F4` | Google Gemini Chat via PicoClaw |
| Claude Code | `claude>` | claude | `#D97706` | Anthropic Claude Anbindung |
| GPT Codex | `codex>` | codex | `#00A67E` | OpenAI GPT-4.1 Interface |
| OpenCode | `oc>` | opencode | `#6366f1` | AI Coding TUI |
| OpenClaw | `🐾>` | openclaw | `#00e5ff` | Agent Gateway Interface |
| NLM CLI | `nlm>` | notebooklm | `#ec4899` | NotebookLM Batch-Generierung |
| ONTHERUN | `mcp>` | mcp-chat | `#fa1e4e` | MCP Dashboard mit 34+ Tools |

### Built-in Befehle

- `help` / `?` — Hilfe-Übersicht
- `clear` / `cls` — Ausgabe leeren
- `status` — Verbindungsstatus aller 8 Tabs
- `version` — Console-Version + aktiver Tab
- `tabs` — Alle verfügbaren Tabs auflisten
- `switch <tab>` — Tab wechseln (z.B. `switch gemini`)
- `learn` — Self-Learning Dashboard (R41 Integration)
- `exit` / `close` — Console schließen

### Features

- **Resize:** Oberkante ziehbar (Min 100px, Max 70% Viewport)
- **Command History:** Pfeiltasten ↑↓ pro Tab
- **State Persistenz:** localStorage `dkz-console-state` (offener Tab, Höhe)
- **ESC-Priorität:** Console hat Vorrang vor Navbar bei ESC-Taste
- **Self-Learning:** `learn` Befehl zeigt DkzLearn-Statistiken
- **PicoClaw Bridge:** Gemini/Claude/Codex routen über PicoClaw
- **ONTHERUN:** Direkte MCP API-Aufrufe via Gateway

### Integration (PFLICHT)

```html
<!-- VOR </body> einfügen — nach dkz-navbar.js -->
<script src="../../shared/dkz-console.js"></script>
```

### NIEMALS

- Console aus Modulen entfernen
- ESC-Shortcut deaktivieren oder überschreiben
- Tab-Reihenfolge ändern ohne Rücksprache
- localStorage-Key `dkz-console-state` umbenennen

---

## R43 — SELFHEALTH DOCK (Sichere Korrektur-Methodik)

> **PFLICHT:** Code-Korrekturen werden NIEMALS direkt am Live-Code durchgeführt.
> Stattdessen wird eine Kopie in einem DOCK-Ordner erstellt, dort geändert,
> getestet und erst nach 100% Fehlfreiheit mit dem Original ausgetauscht.

### DOCK-Schema:

```
DOCK[a1]  = Erster Versuch, Bereich A (Frontend)
DOCK[b2]  = Zweiter Versuch, Bereich B (Backend)
DOCK[c1]  = Erster Versuch, Bereich C (Config)
...
```

### 6 Bereiche:

| Buchstabe | Bereich |
|:----------|:--------|
| **a** | Frontend / HTML / CSS |
| **b** | Backend / Scripts / GAS |
| **c** | Config / Data / JSON |
| **d** | Shared Scripts |
| **e** | NLM / Research |
| **f** | System / Infra |

### Workflow:

1. **IDENTIFIZIEREN** — Was muss geändert werden?
2. **KOPIEREN** — Original in `[WORKSPACE]/SELFHEALTH/DOCK[x1]_beschreibung/`
3. **ÄNDERN** — NUR in DOCK-Kopie, Original NICHT anfassen
4. **PRÜFEN** — Funktioniert? Keine Regression? Shared Scripts kompatibel?
5. **AUSTAUSCHEN** — Original ersetzen, Git: `feat(dock): DOCK[x1] → live`
6. **ABSCHLUSS** — Alle DOCKs als ZIP → `[05_INTERN]/BOB/`

### NIEMALS:

- Direkt am Live-Code ändern ohne DOCK-Kopie
- DOCK-Ordner löschen bevor Korrektur abgeschlossen
- `[WORKSPACE]/SELFHEALTH/` Ordner umbenennen oder verschieben

---

## R44 — HTML AUTO-OPEN PFLICHT

> **PFLICHT:** Wenn ein LLM / Agent eine `.html` Datei erstellt oder ein HTML-basiertes UI fertigstellt (z.B. Dashboard-Modul), MUSS diese Datei **immer sofort** im Browser für den User geöffnet werden.

### Workflow:
1. HTML-Datei erstellen/updaten
2. Sofort im Terminal aufrufen: `start "Pfad\zur\datei.html"` (oder `start file:///...`)
3. Dem User mitteilen, dass die Datei im Browser geöffnet wurde.

