# DEVKiTZ™ — GEMINI.md

> **PFLICHTLEKTÜRE:** Alle ausführlichen Regeln, Workflows und Architektur-Details befinden sich jetzt zentral im PLAYBOOK.
> 🔗 **[DEVKiTZ PLAYBOOK LESEN](file:///C:/DEVKiTZ/04_SYSTEM/DKZ_PLAYBOOK.md)**

---

## Die 10 Gebote (Kernregeln)

1. **NIE LÖSCHEN — IMMER ARCHIVIEREN**: Wissen und Daten gehen niemals verloren. Bei Änderungen nur in `99_ARCHIVE/` verschieben.
2. **GIT COMMIT PFLICHT**: Sofortiger Commit nach jeder funktionalen Änderung (`feat:`, `fix:`, `docs:`).
3. **SEI TEIL DER LÖSUNG**: Der Workflow ist wichtiger als ein schnelles, unsauberes Ergebnis. Verbessere aktiv das System.
4. **XSS-SCHUTZ**: Bei DOM-Manipulationen immer `esc()` vor `innerHTML` verwenden. Sicherheit ist nicht optional.
5. **KEINE FRAMEWORKS (VANILLA ONLY)**: Nur HTML5, CSS3, JS ES6+. Kein React, Vue oder Tailwind (außer bei speziellen Unterprojekten wie Chrome Extensions).
6. **DKZ DESIGN SYSTEM**: Nutze `--accent: #fa1e4e`, `--bg: #060608` und existierende Shared-Scripts.
7. **R24 ARCHIV-ALARM**: Verschieben ins Archiv oder das Löschen von Modulen bedarf der expliziten Bestätigung von `777`.
8. **FRISCHER KONTEXT (RALPH-LOOP)**: Hole dir nur die relevanten Artefakte. Vermeide Context Drift und Halluzinationen.
9. **WISSENHUB PFLICHT**: Speichere jedes erstellte Dokument (Walkthrough, Implementierungsplan, Task) doppelt ab (Iceberg & Hub).
10. **DATEIHOHEIT**: Der User hat absolute Kontrolle. Zeige Pläne vor Massenoperationen.
11. **GRAPHIFY-FIRST PROTOKOLL**: Bei jeder Analyse von Repositories, Ordnern, Clouds oder bei Chat-Anfragen MUSS zwingend zuerst "Graphify" genutzt werden, um Zusammenhänge vorherzusehen und zielgerichtet nur relevante Dokumente zu lesen.
12. **SECOND BRAIN LOCATION**: Das Second Brain (Wissensdatenbank) MUSS immer lokal und separiert abgelegt werden unter `C:\Users\BAZE²\Documents\SecondBrain\`.
13. **MULTI-LLM ORCHESTER**: Das System integriert standardmäßig folgende Agents und Modelle für den Second Brain Zugriff: OpenCode, Pi Agent, ClaudeCode, Manus, Grok, Cursor, Deepseek, Kimi, Minimax, Qwen und Gemma.
