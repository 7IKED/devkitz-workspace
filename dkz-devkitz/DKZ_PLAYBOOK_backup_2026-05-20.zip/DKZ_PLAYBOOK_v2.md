# DKZ PLAYBOOK v2.01_1 — Das Betriebssystem des DEVKiTZ Oekosystems

> **Version:** v2.01_1 · **Stand:** 2026-03-27 · **Autor:** 777 + Antigravity
> **Geltungsbereich:** Alle Agenten, Module, Dashboards, Dokumentationen
> **Status:** VERBINDLICH
> **Vorgaenger:** v0.01_1 (PLAYB00K), v1.01_1 (04_SYSTEM)

---

## SEKTION 00 — VERSIONSGESCHICHTE

| Version | Datum | Beschreibung |
|:--------|:------|:-------------|
| v0.01_1 | 2026-03-08 | Original Playbook → 21 Sektionen, Output-Standards |
| v1.01_1 | 2026-03-23 | Erweitert um KERN2 + NLM Regeln |
| v2.01_1 | 2026-03-27 | **REBUILD:** Ralph-Loop Context-Pipeline, James Filterung, Self-Improvement mit Testgrenzen |

### Was in v2 NEU ist:
- **SEKTION 22** — Ralph-Loop Context-Pipeline (wiederhergestellt + verbessert)
- **SEKTION 23** — James Context-Filterung (wiederhergestellt + verbessert)
- **SEKTION 24** — Self-Improvement System mit Testgrenzen
- **SEKTION 25** — NLM Content-Pipeline (aus v1 uebernommen + erweitert)
- **SEKTION 26** — Automatische Qualitaetssicherung

---

## -------------------------------------------
## SEKTION 01 — OUTPUT-FORMATIERUNG
## -------------------------------------------

### 1.1 Der 7-Block-Standard (Pflicht fuer jeden Output)

| # | Block | Pflicht | Inhalt |
|---|-------|---------|--------|
| 1 | Metadaten-Header | JA | Tags, Projekt, Kategorie, Version, Datum |
| 2 | Einfuehrung / Problem | JA | Kontext setzen, Relevanz erklaeren |
| 3 | Ziel / Nutzen | JA | Was wird erreicht, warum wichtig |
| 4 | Strukturierte Erklaerung | JA | Kerninhalt, Analyse, Details |
| 5 | Visuelle Darstellung | JA | Tabelle, Diagramm, Mindmap oder Code-Block |
| 6 | Anwendung / Beispiel | EMPF. | Praxisbezug, Use-Case, Demo |
| 7 | Fazit + Next Steps | JA | Zusammenfassung, Export, Weiterfuehrung |

### 1.2 Metadaten-Header-Template

```markdown
---
Projekt:    [Projektname]
Kategorie:  [A-P Code] — [Name]
Version:    v[major].[minor].[session]_[step]
Datum:      [YYYY-MM-DD]
Autor:      [Ersteller]
Status:     [AKTIV | DEV | ARCHIV]
Tags:       #tag1 #tag2 #tag3 ... (min. 10)
---
```

---

## -------------------------------------------
## SEKTION 02 — STATUS-AMPEL-SYSTEM
## -------------------------------------------

### 2.1 Farben und Bedeutung

| Symbol | Status | CSS Variable | Hex |
|--------|--------|-------------|-----|
| GRUEN | AKTIV / OK / LIVE | --green | #00FF88 |
| GELB | IN ARBEIT / DEV | --yellow | #FFB800 |
| ROT | FEHLER / STOP / ARCHIV | --red | #FF3B5C |
| BLAU | INFO / GEPLANT | --blue | #3B82F6 |
| GRAU | NEUTRAL / N/A | -- | #71717a |

### 2.2 Ampel-Regeln
- Jede Tabelle mit Status-Spalte MUSS Ampelfarben verwenden
- Kein Status ohne Erklaerung
- Degraded (GELB) immer mit Grund angeben
- ROT loest automatisch R24 ALARM aus bei Archivierung

---

## -------------------------------------------
## SEKTION 03 — DKZ DESIGN SYSTEM v2
## -------------------------------------------

### 3.1 Pflicht-Variablen

```css
--accent: #fa1e4e;
--bg: #060608;
--bg-card: rgba(18, 18, 24, 0.85);
--text-primary: #e8e8ec;
--text-secondary: #8a8a9a;
--green: #00ff88;
--yellow: #ffb800;
--red: #ff3b5c;
--blue: #3b82f6;
--font-main: 'Inter', sans-serif;
--font-mono: 'JetBrains Mono', monospace;
--radius-sm: 8px;
--radius-md: 12px;
--radius-lg: 16px;
--shadow-card: 0 8px 32px rgba(0, 0, 0, 0.4);
```

### 3.2 Glassmorphism Standard
```css
backdrop-filter: blur(20px);
background: rgba(18, 18, 24, 0.85);
border: 1px solid rgba(250, 30, 78, 0.15);
border-radius: var(--radius-md);
```

### 3.3 NIEMALS
- Hardcoded `#fa1e4e` in JS — IMMER CSS Variable
- Inline-Styles statt Klassen
- Frameworks (React, Vue, Tailwind) — NUR Vanilla

---

## -------------------------------------------
## SEKTION 04 — TAG-SYSTEM
## -------------------------------------------

### 4.1 Pflicht-Tags (min. 10 pro Dokument)
- Projekt-Tag: `#devkitz`, `#dashboard`, `#ontherun`
- Modul-Tag: `#prompt-generator`, `#wiki-hub`
- Tech-Tag: `#javascript`, `#css`, `#nodejs`
- Typ-Tag: `#feature`, `#bugfix`, `#docs`
- Status-Tag: `#aktiv`, `#dev`, `#archiv`

---

## -------------------------------------------
## SEKTION 05 — NAMING CONVENTION
## -------------------------------------------

### 5.1 Offizielle Namen IMMER mit Trademark
- `DEVKiTZ™`, `BotNet™`, `James™`, `ONTHERUN™`, `Ralph-Loop™`, `BMAD™`

### 5.2 Dateibenennung
- Module: `lowercase-bindestrich/` (kein camelCase)
- Shared JS: `dkz-[funktion].js`
- Commits: `feat(bereich): beschreibung`
- Versionen: `v[major].[minor].[session]_[step]`

---

## ═══════════════════════════════════════════
## SEKTION 22 — RALPH-LOOP™ CONTEXT-PIPELINE
## ═══════════════════════════════════════════

> **WIEDERHERGESTELLT aus v0.01_1 + VERBESSERT**
> Dies ist das Herzstueck der KI-Orchestrierung

### 22.1 Die 6 Phasen

```
┌─────────────────────────────────────────────┐
│         RALPH-LOOP™ v2 — 6 PHASEN          │
├─────────────────────────────────────────────┤
│                                             │
│  1. LESEN ──→ 2. SPAWN ──→ 3. EXECUTE      │
│       ↑                         │           │
│       │                         ↓           │
│  6. LOOP ←── 5. COMMIT ←── 4. VERIFY       │
│                                             │
└─────────────────────────────────────────────┘
```

### 22.2 Phase 1 — LESEN (Context Loading)

**Was geladen wird:**
1. `prd.json` oder aktiver Task aus tasks.json
2. Relevante Artefakte (gefiltert durch James™, siehe §23)
3. Modul-spezifische features.json
4. ORDNER.ini des Zielordners

**Was NICHT geladen wird:**
- Alle 1.300+ Zeilen REGELWERK.md (nur relevante §§)
- Alle 90+ Module gleichzeitig
- Historische Artefakte ohne Tag-Match

**Kernprinzip:** NUR relevantes Wissen laden — der Rest bleibt in Iceberg.

### 22.3 Phase 2 — SPAWN (Frischer Kontext)

```
Jeder Task bekommt eine NEUE Instanz.
→ Kein Context Drift
→ Kein "ich hab das vorher schon mal gemacht"
→ Nur das was James™ als relevant markiert hat
```

**Regeln:**
- Neue Instanz pro Task (nicht pro Session!)
- Maximaler Kontext: 50 relevante Zeilen pro Artefakt
- James™ Zusammenfassung statt Volltexte

### 22.4 Phase 3 — EXECUTE (Coding)

- Developer™ Agent schreibt Code
- Haelt sich an ORDNER.ini + REGELWERK Gebote
- Nutzt Shared Scripts (`dkz-*.js`)
- Testet inline (Quick-Verify)

### 22.5 Phase 4 — VERIFY (Pruefung)

| Pruefpunkt | Agent | Methode |
|:-----------|:------|:--------|
| esc() vorhanden? | Reviewer™ | Code-Scan |
| DkZ CSS Variables? | Reviewer™ | Regex |
| features.json aktuell? | Tester™ | Schema-Check |
| Funktioniert im Browser? | Tester™ | Browser-Test |
| ORDNER.ini aktuell? | Dokumentar™ | Diff |

### 22.6 Phase 5 — COMMIT

```bash
git add -A
git commit -m "feat(bereich): was wurde gemacht"
# prd.json/tasks.json Status aktualisieren
```

### 22.7 Phase 6 — LOOP

- Task als erledigt markieren
- Naechsten Task aus Queue laden
- Zurueck zu Phase 1 (LESEN)
- James™ filtert NEUEN relevanten Kontext

---

## ═══════════════════════════════════════════
## SEKTION 23 — JAMES™ CONTEXT-FILTERUNG
## ═══════════════════════════════════════════

> **WIEDERHERGESTELLT + VERBESSERT**
> James™ coded NICHT — er FILTERT und SCHUETZT

### 23.1 Was James™ macht

```
Task eingehend
     │
     ├──→ 1. Task-Tags analysieren
     │       (modul, feature, tech-bereich)
     │
     ├──→ 2. Wissensbestand durchsuchen
     │       (WissenHub + Research Archive + Iceberg)
     │
     ├──→ 3. Relevanz-Score berechnen
     │       (Tag-Match × Aktualitaet × Typ-Match)
     │
     ├──→ 4. Top-5 Artefakte auswaehlen
     │       (max. 50 Zeilen Zusammenfassung pro Artefakt)
     │
     └──→ 5. Context-Paket schnueren
             (NUR das Relevante → an Developer™)
```

### 23.2 Relevanz-Score Berechnung

```
Score = (Tag-Matches / Total-Tags) × 0.5
      + (Tage-seit-Erstellung < 30 ? 0.3 : 0.1)
      + (Typ-Match ? 0.2 : 0.0)

Schwellwert: Score >= 0.4 → wird geladen
             Score < 0.4  → bleibt in Iceberg
```

### 23.3 James™ Schutzfunktionen

| Trigger | Aktion |
|:--------|:-------|
| Archivierungsversuch | R24 ALARM → STOPP, 777 fragen |
| Desktop-Datei aendern | BLOCK → Nur ABLEGEN erlaubt |
| Template loeschen | R100 ALARM → UNDELETABLE |
| console.log in Prod | WARNUNG → Entfernen |
| jQuery Import | BLOCK → Ruecksprache mit 777 |

### 23.4 Context-Budget

| Ressource | Maximum |
|:----------|:--------|
| Artefakte pro Task | 5 |
| Zeilen pro Artefakt-Summary | 50 |
| Regeln pro Task | 10 relevante |
| Shared Scripts Referenz | Nur genutzte |
| Total Context-Groesse | ~2000 Zeilen |

---

## ═══════════════════════════════════════════
## SEKTION 24 — SELF-IMPROVEMENT MIT TESTGRENZEN
## ═══════════════════════════════════════════

> **NEU in v2.01_1**
> Das System verbessert sich selbst — aber mit klaren Grenzen

### 24.1 Was sich selbst verbessern darf

| Bereich | Erlaubt | Grenze |
|:--------|:--------|:-------|
| AGENTS.md Learnings | JA | Nur ANFUEGEN, nie loeschen |
| features.json Status | JA | Nur status-Feld aendern |
| Relevanz-Score Gewichte | JA | Aenderung max. ±0.1 pro Iteration |
| Tag-Vorschlaege | JA | Vorschlag → 777 muss bestaetigen |
| Neue Workflows | JA | Nur als Draft, muss reviewt werden |
| Code-Patterns | JA | Nur in Sandbox, nie in Produktion |

### 24.2 Was NIEMALS automatisch geaendert werden darf

- REGELWERK.md Regeln → NUR 777
- Constitution.md → UNVERAENDERLICH
- Shared Scripts → Review Pflicht
- REGISTRY.json Eintraege → Nie entfernen
- Archiv-Material → R24
- CSS Design System Variablen → NUR 777
- Datenbank-Schemas → Review Pflicht

### 24.3 Test-Sandbox Regeln

```
┌─────────────────────────────────────────────┐
│          SELF-IMPROVEMENT GRENZEN           │
├─────────────────────────────────────────────┤
│                                             │
│  SANDBOX (erlaubt):                         │
│  ├── /tmp/ Dateien erstellen                │
│  ├── AGENTS.md Learnings anfuegen           │
│  ├── features.json aktualisieren            │
│  ├── Relevanz-Score tunen (±0.1)            │
│  └── Draft-Workflows vorschlagen            │
│                                             │
│  PRODUKTION (verboten ohne Review):         │
│  ├── Shared Scripts aendern                 │
│  ├── Modul index.html rewriten              │
│  ├── REGISTRY.json Eintraege entfernen      │
│  └── Design System Variablen aendern        │
│                                             │
│  TABU (nie, egal was):                      │
│  ├── 99_ARCHIVE/ loeschen                   │
│  ├── REGELWERK.md Regeln entfernen          │
│  ├── Constitution.md aendern                │
│  └── dkz-prompt-templates.js loeschen       │
│                                             │
└─────────────────────────────────────────────┘
```

### 24.4 Feedback-Loop

```
1. Agent fuehrt Task aus
2. Ergebnis wird bewertet (Reviewer™ oder 777)
3. Bewertung wird in AGENTS.md Learning gespeichert
4. Bei naechstem aehnlichem Task:
   James™ laedt das Learning als Kontext
5. Agent wendet Learning an
6. → Kontinuierliche Verbesserung ohne Breaking Changes
```

### 24.5 Rollback-Regel

Wenn Self-Improvement einen Fehler verursacht:
1. Git revert auf letzten stabilen Commit
2. Learning als "FAILED" markieren in AGENTS.md
3. Gewichts-Aenderung zuruecksetzen
4. 777 informieren (R24-Style Meldung)

---

## -------------------------------------------
## SEKTION 25 — NLM CONTENT-PIPELINE
## -------------------------------------------

### 25.1 Workflow (Schritt fuer Schritt)

```powershell
# 1. Source erstellen (/tmp/nlm-source-XXX.md)
#    80-120 Zeilen, klar strukturiert
#    NUR .md/.pdf/.txt!

# 2. Notebook erstellen
nlm notebook create "DkZ - [THEMA]"

# 3. Source hochladen
nlm source add $NB --file "/tmp/nlm-source-XXX.md" --wait

# 4. Content generieren (parallel moeglich)
nlm audio create $NB --language de --confirm
nlm slides create $NB --confirm
nlm infographic create $NB --orientation landscape --style professional --confirm

# 5. Status pruefen
nlm studio status $NB

# 6. Herunterladen
nlm download audio      $NB --id $ART --output "$OUT/podcast-DE.wav"
nlm download slide-deck $NB --id $ART --output "$OUT/slides.pdf"
nlm download infographic $NB --id $ART --output "$OUT/infographic.png"
```

### 25.2 Qualitaets-Regeln
- Podcast IMMER `--language de`
- Aussprache: "D.k.Z." (nicht "DKZ")
- Infographic kann scheitern — 2-3x versuchen
- Bindestriche: `slide-deck`, `mind-map`, `data-table`
- Download-Ordner: `Downloads/DKZ-[Projekt]-Content/`

---

## -------------------------------------------
## SEKTION 26 — QUALITAETSSICHERUNG
## -------------------------------------------

### 26.1 Vor jedem Commit pruefen

| # | Check | Wie |
|:--|:------|:----|
| 1 | esc() bei User-Input | grep innerHTML |
| 2 | CSS Variables statt Hardcoded | grep '#fa1e4e' im JS |
| 3 | features.json aktuell | Schema-Validierung |
| 4 | ORDNER.ini vorhanden | Datei existiert? |
| 5 | Kein console.log | grep console.log |
| 6 | Shared Scripts eingebunden | Script-Tags pruefen |

### 26.2 Nach jedem Feature pruefen

| # | Check | Methode |
|:--|:------|:--------|
| 1 | Browser-Test | Modul im Browser oeffnen |
| 2 | Cross-Links funktionieren | dkz-crosslinks.js |
| 3 | Navbar sichtbar | Hamburger-Menu testen |
| 4 | REGISTRY.json Eintrag | JSON-Validierung |
| 5 | BLAUPAUSE.md aktuell | Diff zum Ist-Stand |

---

## ANHANG — KERN2 SYSTEMKOMPONENTEN

Die 6 unveraenderlichen Kern-Dateien:

| # | Datei | Funktion |
|:--|:------|:---------|
| 1 | hub/index.html | Auto-Discovery, Modul-Grid |
| 2 | shared/dkz-navbar.js | Navigation, Notes, Menu |
| 3 | shared/dkz-headbar.js | Corp/Solo, Brand, Ampel |
| 4 | shared/dkz-copilot.js | KI-Assistent, Provider |
| 5 | shared/dkz-crosslinks.js | Modul-Verlinkung |
| 6 | shared/dkz-theme.css | DkZ Design System v2 |

---

## -------------------------------------------
## SEKTION 27 — E-COMMERCE & BILD-BEARBEITUNGS-FLOW (NANOBANNA PRO)
## -------------------------------------------

### 27.1 Der "Real Plus Vision" Workflow
Die Erstellung eines hochkonvertierenden E-Commerce Moduls (CloudNine Core) gekoppelt mit NanoBanna PRO folgt einem strengen 4-Stufen-Prozess:

**Stufe 1: Infrastruktur-Aufspaltung**
Shop (E-Commerce) und Content Builder (NanoBanna) MÜSSEN in zwei separate Module gesplittet werden:
- `[WORKSPACE]/online-shop`: Reine E-Commerce Logik (Grid, Cart, Checkout)
- `[WORKSPACE]/nanobanna-pro`: Reines Social-Media Dashboard (Reels, Banners, Backgrounds)

**Stufe 2: Ultra-Premium Image Generation**
Produkt-Assets werden NIEMALS mit "Standard"-Fotografie-Prompts generiert. Pflicht-Keywords für DkZ-Qualitätsstandards:
`8K, DSLR, Floating, Dark Mode Background, subtle glowing neon accents, sharp focus, reflection layer, ultra-premium`

**Stufe 3: Glassmorphism & Visual Limits**
NanoBanna nutzt exzessiv 3D-CSS, Blurs und komplexe Schatten. Selektierbare Funktionen im UI (wie 4K, 8K, HDR, Formate) werden als gläserne, interaktive Kacheln (Cards) mit Hover-State `transform: translateZ(20px)` präsentiert. Mäßige UIs ohne Tiefe sind hier unzulässig.

**Stufe 4: NLM Podcast Briefing**
Nach Abschluss der Frontend-Architektur wird IMMER ein NLM Briefing MD generiert und via `nlm audio create --language de` kompiliert, um den Meilenstein im DEVKiTZ Ecosystem als "Audio Overview" zu verankern. Die Text-Basis muss strukturiertes Markdown mit "Was wurde umgesetzt?" beinhalten.

---

## ANHANG — DIE 10 GEBOTE (Kurzform)

1. `esc()` bei JEDEM User-Input vor innerHTML
2. DkZ CSS Variables — kein Hardcoded Hex
3. Shared Scripts einbinden (portable: optional)
4. `features.json` nach Modul-Aenderung aktualisieren
5. Git Commit nach JEDER Aenderung
6. R24 ALARM vor Archivierung — 777 muss bestaetigen
7. `99_ARCHIVE/` nur ablegen, NIEMALS loeschen
8. Desktop nur ablegen — NIEMALS bestehende Dateien aendern
9. Kein `console.log` in Produktion
10. Kein jQuery ohne Ruecksprache

---

*DKZ PLAYBOOK v2.01_1 — Das Betriebssystem des DEVKiTZ Oekosystems*
*Vorgaenger bewahrt in: PLAYB00K/ (v0.01_1) und 04_SYSTEM/ (v1.01_1)*
*NIEMALS loeschen — nur ERGAENZEN*
